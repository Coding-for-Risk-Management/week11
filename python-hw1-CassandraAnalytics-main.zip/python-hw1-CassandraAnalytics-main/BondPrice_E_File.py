

def getBondPrice_E(face, couponRate, yc):
    return(2098949)
