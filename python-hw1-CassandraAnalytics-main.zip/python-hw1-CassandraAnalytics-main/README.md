# Set Up


Be sure to have GitHub Desktop installed and have a free GitHub account installed.

Move the Example files into the local repository (That’s the folder you have selected on your computer):

Hit the Green Button that says Code and then select use GitHub Desktop.

Select a folder on your computer.  It will become the local repository.

Commit the change.

# First Practice Steps

Move the empty practice files into your local repository.

Commit and then push the local repository.

Go to action to observe the test of the file. (It will fail at first. This is for practice.)

On your computer Open and update the WhoAmI_File.py

Commit and then push the local repository.

Go to action to observe the test of the file.
